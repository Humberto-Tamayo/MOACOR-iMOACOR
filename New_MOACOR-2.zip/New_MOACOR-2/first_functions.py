# Optimization Test Problems

# https://www.sfu.ca/~ssurjano/optimization.html

# The functions listed below are some of the common functions and datasets used for testing optimization algorithms. 
# They are grouped according to similarities in their significant physical properties and shapes.


import numpy as np
import math
from six.moves import reduce

# Its better if all the vectors and matrices are np vectors and np matrix

# Many Local Minima

# ACKLEY FUNCTION
# Dimensions d
# The function is usually evaluated on the hypercube xi ∈ [-32.768, 32.768], for all i = 1,…,d.
# Recommended variable values are: a = 20, b = 0.2 and c = 2π. 
def ackleyFunction(vec,a,b,c):
    d = len(vec)
    part1 = a * np.exp( -1 * b * ( np.sqrt( (1/d) * np.dot(vec,vec) ) ) )
    count = 0
    for x in range(d):
        count = count + np.cos( c * vec[x] )    
    part2 = np.exp( (1/d) * count )  
    evaluation = -1 * part1 -1 * part2 + a + np.exp(1) 
    return evaluation

def ackleyFunction_data():
    return 32.768,-32.768,0,20,np.power(10.0,-10.0)

# BUKIN FUNCTION N. 6
# Dimensions 2
# The function is usually evaluated on the rectangle x1 ∈ [-15, -5], x2 ∈ [-3, 3]
def bukinFunctionN6(vec):
    part1 = 100 * np.sqrt( np.absolute( vec[1] - 0.01 * vec[0] * vec[0] ) )
    part2 = 0.01 * np.absolute( vec[0] + 10 )
    return part1 + part2

def bukinFunctionN6_data():
    return 3,-15,0,2,np.power(10.0,-10.0)

# CROSS-IN-TRAY FUNCTION
# Dimensions 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2.
def crossInTrayFunction(vec):
    a = np.absolute( np.sin(vec[0]) * np.sin(vec[1]) * np.exp( np.absolute( 100 - ( np.sqrt( vec[0]*vec[0] + vec[1]*vec[1] )/np.pi)))) + 1
    part1 = -0.0001 * np.power(a, 0.1)
    return part1

# DROP-WAVE FUNCTION
# Dimensions 2
# The function is usually evaluated on the square xi ∈ [-5.12, 5.12], for all i = 1, 2.
def dropWaveFunction(vec):
    part1 = 1 + np.cos( 12 * np.sqrt( vec[0]*vec[0] + vec[1]*vec[1] ))
    part2 = 0.5 * ( vec[0]*vec[0] + vec[1]*vec[1] ) + 2
    return ( -1 * part1 ) / part2

def dropWaveFunction_data():
    return 5.12,-5.12,-1,2,np.power(10.0,-10.0)

# EGGHOLDER FUNCTION
# Dimensions 2
# The function is usually evaluated on the square xi ∈ [-512, 512], for all i = 1, 2.
def eggholderFunction(vec):
    a = np.sin( np.sqrt( np.absolute( vec[1] + vec[0]/2 +47 )))
    b = np.sin( np.sqrt( np.absolute( vec[0] - ( vec[1] + 47 ))))
    return -1 * ( vec[1] +47 ) * a - vec[0] * b 

def eggholderFunction_data():
    return 512,-512,-959.6406627106155,2,np.power(10.0,-10.0)

# GRAMACY & LEE (2012) FUNCTION
# Dimensions 1
# This function is usually evaluated on the x ∈ [0.5, 2.5].
def gramacyYLeeFunction(vec):
    return np.sin( 10 * np.pi * vec[0] ) / ( 2 * vec[0] ) + np.power((vec[0] - 1), 4)

# GRIEWANK FUNCTION 
# Dimensions d
# The function is usually evaluated on the hypercube xi ∈ [-600, 600], for all i = 1, …, d.
def griewankFunction(x):
    d = len(x)
    partA = 0
    partB = 1
    for i in range(d):
        partA += x[i]**2
        partB *= math.cos(float(x[i]) / math.sqrt(i+1))
    return 1 + (float(partA)/4000.0) - float(partB) 

def griewankFunction_data():
    return 600,-600,0,20,np.power(10.0,-10.0)

# HOLDER TABLE FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2.
def holderTableFunction(vec):
    part1 = np.exp( np.absolute( 1 - np.sqrt( vec[0]*vec[0] + vec[1]*vec[1]) / np.pi ))
    part2 = np.sin( vec[0] ) * np.cos( vec[1] )
    return -1 * np.absolute( part2 * part1 )

def holderTableFunction_data():
    return 10,-10,-19.208502567767606,2,np.power(10.0,-10.0)

# LANGERMANN FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [0, 10], for all i = 1, …, d.
# The columns of the matrix a must be equal to d.
# The rows of the matrix a and the length of vector c must be equal to m.
def langermanFunction(m,c,a,vec):
    d = len(vec)
    evaluation = 0
    for i in range(m):
        part1 = c[i]
        for2 = 0
        for ii in range(d):
            for2 = (vec[ii] - a[i][ii]) * (vec[ii] - a[i][ii]) + for2
        part2 = np.exp( (-1/np.pi) * for2 )
        part3 = np.cos(np.pi * for2)
        evaluation = evaluation + part1 * part2 * part3
    return evaluation

# LEVY FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-10, 10], for all i = 1, …, d.
def levyFunction(vec):
    d = len(vec)-1
    w = []
    for x in vec:
        w.append(1+(x-1)/4)
    p1 = np.power(np.sin(np.pi * w[0]),2)
    p2 = 0
    for i in range(d-1):
        p2 = np.power(w[i]-1,2) * (1 + 10 * np.power(np.pi*w[i]+1,2)) + p2
    p3 = np.power(w[d]-1,2) * ( 1 + np.power(2*np.pi*w[d],2))
    return p1+p2+p3

def levyFunction_data():
    return 10,-10,0,20,np.power(10.0,-10.0)

# LEVY FUNCTION N. 13
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2.
def levyFunction13(vec):
    p1 = np.power(np.sin(3*np.pi*vec[0]),2)
    p2 = np.power(vec[0]-1,2) * (1 + np.power(np.sin(3*np.pi*vec[1]),2))
    p3 = np.power(vec[1]-1,2) * (1 + np.power(np.sin(2*np.pi*vec[1]),2))
    return p1+p2+p3

# RASTRIGIN FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-5.12, 5.12], for all i = 1, …, d.
def rastriginFunction(x):
    d = len(x)
    p1 = 10*d
    p2 = 0
    for i in range(d):
        p2 = p2 + np.power(x[i],2) - 10 * np.cos(2*np.pi*x[i])
    return p1+p2

def rastriginFunction_data():
    return 5.12,-5.12,0,20,np.power(10.0,-10.0)

# SCHAFFER FUNCTION N. 2
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-100, 100], for all i = 1, 2.
def schafferFunction2(x):
    p1 = np.power(np.sin(x[0]*x[0]-x[1]*x[1]),2) - 0.5
    p2 = np.power(1 + 0.001 * x[0]*x[0]+x[1]*x[1],2)
    return 0.5 + p1/p2

def schafferFunction2_data():
    return 100,-100,0,2,np.power(10.0,-10.0)

# SCHAFFER FUNCTION N. 4
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-100, 100], for all i = 1, 2.
def schafferFunction4(x):
    p1 = np.power(np.cos(np.sin(np.absolute(x[0]*x[0]-x[1]*x[1])))-0.5,2)
    p2 = np.power(1 + 0.001 * x[0]*x[0]+x[1]*x[1],2)
    return 0.5 + p1/p2

# SCHWEFEL FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-500, 500], for all i = 1, …, d.
def schwefelFunction(x):
    d = len(x)
    p1 = 418.9829*d
    p2 = 0
    for i in range(d):
        p2 = p2 + x[i]*np.sin(np.sqrt(np.absolute(x[i])))
    return p1-p2

def schwefelFunction_data():
    return 500,-500,0.00012727837565762457,2,np.power(10.0,-10.0)

# SHUBERT FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2, although this may be restricted to the square xi ∈ [-5.12, 5.12], for all i = 1, 2.
def shubertFunction(x):
    p1 = 0
    for i in range(5):
        p1 = p1 + i * np.cos((i+1)*x[0]+i)
    p2 = 0
    for i in range(5):
        p2 = p2 + i * np.cos((i+1)*x[1]+i)
    return p1*p2


# Bowl Shaped

# BOHACHEVSKY FUNCTIONS
# Dimensions: 2
# The functions are usually evaluated on the square xi ∈ [-100, 100], for all i = 1, 2.
def bohachevskyFunction1(x):
    return x[0]*x[0] + 2*x[1]*x[1] - 0.3*np.cos(3*np.pi*x[0]) - 0.4*np.cos(4*np.pi*x[1]) + 0.7

def bohachevskyFunction1_data():
    return 100,-100,0,2,np.power(10.0,-10.0)

def bohachevskyFunction2(x):
    return x[0]*x[0] + 2*x[1]*x[1] - 0.3*np.cos(3*np.pi*x[0])*np.cos(4*np.pi*x[1]) + 0.3

def bohachevskyFunction3(x):
    return x[0]*x[0] + 2*x[1]*x[1] - 0.3*np.cos(3*np.pi*x[0]+0.4*np.pi*x[1]) + 0.3

# PERM FUNCTION 0, D, BETA
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-d, d], for all i = 1, …, d.
'''
def permFunction(x,beta):
    d = len(x)
    p1 = 0
    for i in range(d):
        for j in range(d):
            p1 = p1 + ((j +1+ beta)*(x[j]-1/(j+1)))*((j +1+ beta)*(x[j]-1/(j+1)))
    return p1
'''

def permFunction_data():
    return 20,-20,0,20,np.power(10.0,-10.0)

# ROTATED HYPER-ELLIPSOID FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-65.536, 65.536], for all i = 1, …, d.
def rotatedHyperEllipsoidFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        for j in range(i):
            p1 = p1 + x[j]*x[j]
    return p1

def rotatedHyperEllipsoidFunction_data():
    return 65.536,-65.536,0,20,np.power(10.0,-10.0)

# SPHERE FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-5.12, 5.12], for all i = 1, …, d.
def sphereFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + x[i]*x[i]
    return p1

def sphereFunction_data():
    return 5.12,-5.12,0,20,np.power(10.0,-10.0)

# SUM OF DIFFERENT POWERS FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-1, 1], for all i = 1, …, d.
def sumOfDifferentPowersFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + np.power(np.absolute(x[i]),i+2)
    return p1

# SUM SQUARES FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-10, 10], for all i = 1, …, d, although this may be restricted to the hypercube xi ∈ [-5.12, 5.12], for all i = 1, …, d.
def sumSquaresFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + (i+1)*x[i]*x[i]
    return p1

# TRID FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-d2, d2], for all i = 1, …, d.
def tridFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + (x[i]-1)*(x[i]-1)
    p2 = 0
    for i in range(d-1):
        p2 = p2 + x[i+1]*x[i]
    return p1-p2


# Plate-Shaped

# BOOTH FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2.
def boothFunction(x):
    p1 = np.power(x[0]+2*x[1]-7,2)
    p2 = np.power(2*x[0]+x[1]-5,2)
    return p1+p2

# MATYAS FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-10, 10], for all i = 1, 2.
def matyasFunction(x):
    p1 = 0.26*(x[0]*x[0]+x[1]*x[1])
    p2 = 0.48*x[0]*x[1]
    return p1-p2

def matyasFunction_data():
    return 10,-10,0,2,np.power(10.0,-10.0)

# MCCORMICK FUNCTION
# Dimensions: 2
# The function is usually evaluated on the rectangle x1 ∈ [-1.5, 4], x2 ∈ [-3, 4].
def mccormickFunction(x):
    p1 = np.sin(x[0]+x[1]) + np.power(x[0]-x[1],2)
    p2 = -1.5*x[0] + 2.5*x[1] + 1
    return p1+p2

def mccormickFunction_data():
    return 4,-3,-1.9132229548822741,2,np.power(10.0,-10.0)

# POWER SUM FUNCTION
# Dimensions: d
# The recommended value of the b-vector, for d = 4, is: b = (8, 18, 44, 114).
# The function is usually evaluated on the hypercube xi ∈ [0, d], for all i = 1, …, d.
def powerSumFunction(x,b):
    d = len(x)
    p1 = 0
    for i in range(d):
        p2 = 0
        for j in range(d):
            p2 = p2 + x[j]
        p1 = p1 + (p2-b[i])*(p2-b[i])
    return p1

# ZAKHAROV FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-5, 10], for all i = 1, …, d.
def zakharovFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + x[i]*x[i]
    p2 = 0
    for i in range(d):
        p2 = p2 + 0.5*i*x[i]
    p2 = p2*p2
    p3 = 0
    for i in range(d):
        p3 = p3 + 0.5*i*x[i]
    p3 = np.power(p3,4)
    return p1+p2+p3

def zakharovFunction_data():
    return 10,-5,0,20,np.power(10.0,-10.0)


# Valley-Shaped

# THREE-HUMP CAMEL FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-5, 5], for all i = 1, 2.
def threeHumpCamelFunction(x):
    return 2*x[0]*x[0] - 1.05*np.power(x[0],4) + np.power(x[0],6)/6 + x[0]*x[1] + x[1]*x[1]

# SIX-HUMP CAMEL FUNCTION
# Dimensions: 2
# The function is usually evaluated on the rectangle x1 ∈ [-3, 3], x2 ∈ [-2, 2].
def sixHumpCamelFunction(x):
    p1 = (4-2.1*x[0]*x[0]+np.power(x[0],4)/3)*x[0]*x[0]
    p2 = x[0]*x[1]
    p3 = (-4+4*x[1]*x[1])*x[1]*x[1]
    return p1+p2+p3

def sixHumpCamelFunction_data():
    return 3,-3,-1.031628453,2,np.power(10.0,-8.0)

# DIXON-PRICE FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-10, 10], for all i = 1, …, d.
def dixonPriceFunction(x):
    d = len(x)
    p1 = np.power(x[0]-1,2)
    p2 = 0
    for i in range(d-1):
        i = i+1
        p2 = p2 + i*np.power(2*x[i]*x[i]-x[i-1],2)
    return p1+p2

def dixonPriceFunction_data():
    return 10,-10,0,20,np.power(10.0,-10.0)

# ROSENBROCK FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-5, 10], for all i = 1, …, d, although it may be restricted to the hypercube xi ∈ [-2.048, 2.048], for all i = 1, …, d.
def rosenbrockFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d-1):
        p1 = p1 + ( 100*np.power((x[i+1]-x[i]*x[i]),2) + np.power(x[i]-1,2) )
    return p1

def rosenbrockFunction_data():
    return 10,-5,0,2,np.power(10.0,-10.0)


# Steep Ridges/Drops

# DE JONG FUNCTION N. 5
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-65.536, 65.536], for all i = 1, 2.
def deJongFunctionN(x):
    A = [-32., -16., 0., 16., 32.]
    a1 = A * 5
    a2 = reduce(lambda x1,x2: x1+x2, [[c] * 5 for c in A])
    p1 = 0
    for i in range(25):
        p1 = p1 + 1 / ( i+1 + (np.power(x[0]-a1[i],6)) + np.power(x[1]-a2[i],6))
    p2 = 0.002 + p1
    p3 = np.power(p2,-1)
    return p3

# EASOM FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-100, 100], for all i = 1, 2.
def easomFunciton(x):
    p1 = np.cos(x[0])*np.cos(x[1])
    p2 = np.exp(-1 * np.power(x[0]-np.pi,2) - np.power(x[1]-np.pi,2))
    return -1*p1*p2

def easomFunciton_data():
    return 100,-100,-1,2,np.power(10.0,-10.0)

# MICHALEWICZ FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [0, π], for all i = 1, …, d.
def michalewiczFunction(x):
    m = 10
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + np.sin(x[i])*np.power(np.sin((i+1)*x[i]*x[i]/np.pi),2*m)
    return -1*p1

def michalewiczFunction_data():
    return np.pi,0,-9.66015,10,np.power(10.0,-4.0)


# Other

# BEALE FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-4.5, 4.5], for all i = 1, 2.
def bealeFunction(x):
    p1 = np.power(1.5-x[0]+x[0]*x[1],2)
    p2 = np.power(2.25-x[0]+x[0]*x[1]*x[1],2)
    p3 = np.power(2.625-x[0]+x[0]*np.power(x[1],3),2)
    return p1+p2+p3

# BRANIN FUNCTION
# Dimensions: 2
# This function is usually evaluated on the square x1 ∈ [-5, 10], x2 ∈ [0, 15].
def braninFunction(x):
    a= 1
    b= 5.1/(4*np.pi*np.pi)
    c= 5/np.pi
    r = 6
    s= 10
    t=1/(8*np.pi) 
    p1 = a*np.power(x[1]-b*x[0]*x[0]+c*x[0]-r,2)
    p2 = s*(1-t)*np.cos(x[0])+s
    return p1+p2

def braninFunction_data():
    return 15,-5,0.39788735772973816,2,np.power(10.0,-6.0)

# COLVILLE FUNCTION
# Dimensions: 4
# The function is usually evaluated on the hypercube xi ∈ [-10, 10], for all i = 1, 2, 3, 4.
def colvilleFunction(x):
    p1 = 100*np.power(x[0]*x[0]-x[1],2) + np.power(x[0]-1,2)
    p2 = np.power(x[2]-1,2) + 90*np.power(x[2]*x[2]-x[3],2)
    p3 = 10.1*(np.power(x[1]-1,2) + np.power(x[3]-1,2))
    p4 = 19.8*(x[1]-1)*(x[3]-1)
    return p1+p2+p3+p4

# FORRESTER ET AL. (2008) FUNCTION
# Dimensions 1
# The function is evaluated on x ∈ [0, 1].
def forrester2008Function(x):
    a = x[0]
    return (6*a-2)*(6*a-2)*np.sin(12*a-4)

# GOLDSTEIN-PRICE FUNCTION
# Dimensions: 2
# The function is usually evaluated on the square xi ∈ [-2, 2], for all i = 1, 2.
def goldsteinPriceFunction(x):
    x1 = x[0]
    x2 = x[1]
    p1 = np.power(x1+x2+1,2)
    p2 = 19-14*x1+3*x1*x1-14*x2+6*x1*x2+3*x2*x2
    p3 = np.power(2*x1-3*x2,2)
    p4 = 18-32*x1+12*x1*x1+48*x2-36*x1*x2+27*x2*x2
    return (1+p1*p2)*(30+p3*p4)

def goldsteinPriceFunction_data():
    return 2,-2,3,2,np.power(10.0,-10.0)

# HARTMANN 3-DIMENSIONAL FUNCTION
# Dimensions: 3
# The function is usually evaluated on the hypercube xi ∈ (0, 1), for all i = 1, 2, 3.
def hartmann3DFunction(x):
    alpha = [1.0,1.2,3.0,3.2]
    a = np.matrix([[3.0,10,30],[0.1,10,35],[3.0,10,30],[0.1,10,35]])
    print(a[3,2])
    p = np.power(10.0,-4.0)*np.matrix([[3689,1170,2673],[4699,4387,7470],[1091,8732,5547],[381,5743,8828]])
    p1 = 0
    for i in range(4):
        p2 = 0
        for j in range(3):
            p2 = p2 - a[i,j]*np.power(x[j]-p[i,j],2)
        p1 = p1 - alpha[i]*np.exp(p2)
    return p1
    
# HARTMANN 4-DIMENSIONAL FUNCTION
# Dimensions: 4
# The function is usually evaluated on the hypercube xi ∈ (0, 1), for all i = 1, 2, 3, 4.
def hartmann4DFunction(x):
    alpha = [1.0,1.2,3.0,3.2]
    a = np.matrix([[10,3,17,3.5,1.7,8],[0.05,10,17,0.1,8,14],[3,3.5,1.7,10,17,8],[17,8,0.05,10,0.1,14]])
    p = np.power(10.0,-4.0)*np.matrix([[1312,1696,5569,124,8283,5886],
                                      [2329,4135,8307,3736,1004,9991],
                                      [2348,1451,3522,2883,3047,6650],
                                      [4047,8828,8732,5743,1091,381]])
    p1 = 0
    for i in range(4):
        p2 = 0
        for j in range(4):
            p2 = p2 - a[i,j]*np.power(x[j]-p[i,j],2)
        p1 = p1 - alpha[i]*np.exp(p2)
    p3 = (1.1+p1)/0.839
    return p3

# HARTMANN 6-DIMENSIONAL FUNCTION
# Dimensions: 6
# The function is usually evaluated on the hypercube xi ∈ (0, 1), for all i = 1, …, 6.
def hartmann6DFunction(x):
    alpha = [1.0,1.2,3.0,3.2]
    a = np.matrix([[10,3,17,3.5,1.7,8],[0.05,10,17,0.1,8,14],
                   [3,3.5,1.7,10,17,8],[17,8,0.05,10,0.1,14]])
    p = np.power(10.0,-4.0)*np.matrix([[1312,1696,5569,124,8283,5886],[2329,4135,8307,3736,1004,9991],
                                       [2348,1451,3522,2883,3047,6650],[4047,8828,8732,5743,1091,381]])
    p1 = 0
    for i in range(4):
        p2 = 0
        for j in range(6):
            p2 = p2 - a[i,j]*np.power(x[j]-p[i,j],2)
        p1 = p1 - alpha[i]*np.exp(p2)
    return p1

def hartmann6DFunction_data():
    return 0.9999999999,0.0000000001,-3.322368011391339,6,np.power(10.0,-5.0)

    
# PERM FUNCTION D, BETA
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-d, d], for all i = 1, …, d.

def permFunction(x,beta):
    d = len(x)
    p1 = 0
    for i in range(d):
        p2 = 0
        for j in range(d):
            p2 = p2 + (np.power(j+1,i+1)+beta)*((np.power((x[j]/(j+1)),i+1))-1)
        p1 = p1 + p2*p2
    return p1

# POWELL FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-4, 5], for all i = 1, …, d.
def powellFunction(x):
    d = len(x)
    m1 = 0
    for i in range(int(d/4)):
        p1 = np.power(x[4*i-3]+10*x[4*i-1],2) + 5*np.power(x[4*1-1]-x[4*i],2)
        p2 = np.power(x[4*i-2]-2*x[4*i-1],4) + 10*np.power(x[4*i-3]-x[4*i],4)
        m1 = m1 + p1 + p2
    return m1
    
# SHEKEL FUNCTION
# Dimensions: 4
# The function is usually evaluated on the hypercube xi ∈ [0, 10], for all i = 1, 2, 3, 4.
def shekelFunction(x):
    m = 10
    b = (1/10)*np.array([1,2,2,4,4,6,3,7,5,5])
    c = np.matrix([[4,1,8,6,3,2,5,8,6,7],[4,1,8,6,7,9,3,1,2,3.6],
                   [4,1,8,6,3,2,5,8,6,7],[4,1,8,6,7,9,3,1,2,3.6]])
    p1 = 0
    for i in range(m):
        p2 = 0
        a = 0
        for j in range(4):
            a = a + np.power(x[j]-c[j,i],2)
        p2 = p2 + np.power(a+b[i],-1.0)
        p1 = p1 - p2
    return p1

def shekelFunction_data():
    return 10,0,-10.536283726219603,4,np.power(10.0,-4.0)

# STYBLINSKI-TANG FUNCTION
# Dimensions: d
# The function is usually evaluated on the hypercube xi ∈ [-5, 5], for all i = 1, …, d.
def styblinskiTangFunction(x):
    d = len(x)
    p1 = 0
    for i in range(d):
        p1 = p1 + np.power(x[i],4) - 16*np.power(x[i],2) + 5*x[i]
    return 0.5*p1

def styblinskiTangFunction_data():
    return 5,-5,-39.16599*20,20,np.power(10.0,-5.0)
















    
    


















