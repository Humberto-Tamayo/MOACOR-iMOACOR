#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan  9 00:16:53 2023

@author: macbook
"""

# It is important to be sure that every function that I make from now on works with the numpy library. 
# Do not mix lists with numpy arrays. 

import first_functions as ff


import numpy as np
import math

def same_boundaries(n_vars,a,b):
    data = np.array([])
    for i in range(n_vars):
        data = np.append(data,a)
        data = np.append(data,b)
    return data
    

# My test functions

def mop_beto1_data(n_vars):
    data = np.array([])
    for i in range(n_vars):
        a = -1 * i * i - 2
        b = i * i + 2
        data = np.append(data,a)
        data = np.append(data,b)
    return data

def mop_beto1(x,n_funcs):
    evaluation = np.array([])
    for i in range(n_funcs):
        evaluation = np.append(evaluation,ff.sphereFunction(x-i))
    return evaluation

# Problems in the MOACOR paper

# SCH1
def SCH1_data(n_vars):
    return same_boundaries(n_vars,-1000,1000)

def SCH1(x):
    x1 = x[0]
    evaluation = np.array([])
    evaluation = np.append(evaluation,x1**2)
    evaluation = np.append(evaluation,(x1-2)**2)
    return evaluation

def SCH2_data(n_vars):
    return same_boundaries(n_vars,-5,10)

def SCH2(x):
    x1 = x[0]
    evaluation = np.array([])
    f1 = 0
    if (x1 <= 1):
        f1 = -1*x1
    if (1 < x1) and (x1 <= 3):
        f1 = -2 + x1
    if (3 < x1) and (x1 <= 4):
        f1 = 4 - x1
    if (x1 > 4):
        f1 = x1 - 4
    f2 = ( x1 - 5 )**2
    evaluation = np.append(evaluation,f1)
    evaluation = np.append(evaluation,f2)
    return evaluation



def DEB1_data(n_vars):
    return same_boundaries(n_vars,0,1)

def DEB1(x):
    alpha = 2
    q = 4
    x1 = x[0]
    x2 = x[1]
    evaluation = np.array([])
    evaluation = np.append(evaluation,x1)
    p1 = ( 1 + 10*x2 )
    f2 = p1 * ( 1 - ( x1/p1 )**alpha - ( (x1*np.sin(2*np.pi*q*x1))/p1 ) )
    evaluation = np.append(evaluation,f2)
    return evaluation
    
    

# DTLZ Test Problems

# DTLZ1
def DTLZ1_data(n_vars):
    return same_boundaries(n_vars,0,1)

def g_m(x):
    length = len(x)
    p1 = 0
    for i in range(length):
        p1 = p1 + (x[i]-0.5)**2 - np.cos(20*np.pi*(x[i]-0.5))
    return 100*(length+p1)
    
# n must be bigger or equal than the number of functions to optimize.
def DTLZ1(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_m(y)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*x[i]
    f1 = 0.5 * (1+g) * a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*x[i]
            fj = 0.5 * (1+g) * (1-x[m-(j+2)]) * b
            evaluation = np.append(evaluation,fj)       
    fm = 0.5 * (1+g) * (1-x[0])
    evaluation = np.append(evaluation,fm) 
    return evaluation


# DTLZ2
def DTLZ2_data(n_vars):
    return same_boundaries(n_vars,0,1)

def g_DTLZ2(y):
    a = len(y)
    b = 0
    for i in range(a):
        b = b + (y[i]*0.5)**2
    return b

def DTLZ2(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_DTLZ2(y)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*(np.cos(np.pi*0.5*x[i]))
    f1 = (1+g)*a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*np.cos(np.pi*0.5*x[i])
            fj = (1+g)*b*np.sin(x[m-(j+2)]*np.pi*0.5)
            evaluation = np.append(evaluation,fj) 
    fm = (1+g)*np.sin(x[0]*np.pi*0.5)
    evaluation = np.append(evaluation,fm) 
    return evaluation

# DTLZ3
def DTLZ3_data(n_vars):
    return same_boundaries(n_vars,0,1)

def DTLZ3(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = ff.rastriginFunction(y)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*(np.cos(np.pi*0.5*x[i]))
    f1 = (1+g)*a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*np.cos(np.pi*0.5*x[i])
            fj = (1+g)*b*np.sin(x[m-(j+2)]*np.pi*0.5)
            evaluation = np.append(evaluation,fj) 
    fm = (1+g)*np.sin(x[0]*np.pi*0.5)
    evaluation = np.append(evaluation,fm) 
    return evaluation


# DTLZ4
def DTLZ4_data(n_vars):
    return same_boundaries(n_vars,0,1)

def g_DTLZ4_5(y):
    a = len(y)
    b = 0
    for i in range(a):
        b = b + (y[i]-0.5)**2
    return b

def DTLZ4(x,n_funcs,n_vars):
    alpha = 100
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_DTLZ4_5(y)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*(np.cos(np.pi*0.5*(x[i]**alpha)))
    f1 = (1+g)*a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*np.cos(np.pi*0.5*(x[i]**alpha))
            sin_val = (np.sin(x[m-(j+2)]**alpha*np.pi*0.5))
            fj = (1+g)*b*sin_val
            evaluation = np.append(evaluation,fj) 
    fm = (1+g)*np.sin((x[0]**alpha)*np.pi*0.5)
    evaluation = np.append(evaluation,fm) 
    return evaluation


# DTLZ5
def DTLZ5_data(n_vars):
    return same_boundaries(n_vars,0,1)

def DTLZ5(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_DTLZ4_5(y)
    delta = []
    delta.append(x[0])
    for i in range(m-2):
        value = (1+2*g*x[i+1])/(2*(1+g))
        delta.append(value)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*(np.cos(np.pi*0.5*(delta[i])))
    f1 = (1+g)*a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*np.cos(np.pi*0.5*(delta[i]))
            sin_val = (np.sin(delta[m-(j+2)]*np.pi*0.5))
            fj = (1+g)*b*sin_val
            evaluation = np.append(evaluation,fj) 
    fm = (1+g)*np.sin((delta[0])*np.pi*0.5)
    evaluation = np.append(evaluation,fm) 
    return evaluation

# DTLZ6
def DTLZ6_data(n_vars):
    return same_boundaries(n_vars,0,1)

def g_DTLZ6(y):
    a = len(y)
    b = 0
    for i in range(a):
        b = b + y[i]**0.1
    return b
    

def DTLZ6(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_DTLZ6(y)
    delta = []
    delta.append(x[0])
    for i in range(m-2):
        value = (1+2*g*x[i+1])/(2*(1+g))
        delta.append(value)
    f1 = 0
    a = 1
    for i in range(m-1):
        a = a*(np.cos(np.pi*0.5*(delta[i])))
    f1 = (1+g)*a
    evaluation = np.append(evaluation,f1)
    if (m > 2):
        for j in range(m-2):
            b = 1
            fj = 0
            for i in range(m-(j+2)):
                b = b*np.cos(np.pi*0.5*(delta[i]))
            sin_val = (np.sin(delta[m-(j+2)]*np.pi*0.5))
            fj = (1+g)*b*sin_val
            evaluation = np.append(evaluation,fj) 
    fm = (1+g)*np.sin((delta[0])*np.pi*0.5)
    evaluation = np.append(evaluation,fm) 
    return evaluation

# DTLZ7
def DTLZ7_data(n_vars):
    return same_boundaries(n_vars,0,1)

def g_DTLZ7(y):
    a = len(y)
    b = 0
    for i in range(a):
        b = b + y[i]
    return 1+b*(9/a)

def DTLZ7(x,n_funcs,n_vars):
    m = n_funcs
    evaluation = np.array([])
    y = x[m-1:n_vars]
    g = g_DTLZ7(y)
    for i in range(m-1):
        evaluation = np.append(evaluation,x[i]) 
    a = 0
    for i in range(m-1):
        a = a + (((x[i])/(1+g))*(1+np.sin(3*np.pi*x[i])))  
    fm = (1+g)*(m-a)
    evaluation = np.append(evaluation,fm) 
    return evaluation



# Irregular MOPs.
# The recomended n_vars are 10, 5 for K and 5 for L
def IMOPS_data(n_vars):
    return same_boundaries(n_vars,0,1)


def g_imops(x,k,n_vars):
    a = n_vars
    l = a-k
    b = 0
    for i in range(l):
        b = b + (x[k+i]-0.5)**2
    return b

def y1_imops(x,k,a1):
    a = 0
    for i in range(k):
        a = a + x[i]
    res = ((1/k)*a)**a1
    return res

def y2_imops(x,k,a2):
    a = 0
    for i in range(math.ceil(k/2)):
        a = a + x[i]
    return ((1/(math.ceil(k/2)))*a)**a2

def y3_imops(x,k,a3):
    a = 0
    j = math.ceil(k/2)+1
    for i in range(k-j+1):
        a = a + x[j+i-1]
    return ((1/(math.floor(k/2)))*a)**a3

'''
def g_imops(x,k,n_vars):
    b = (x[5]-0.5 )** 2 + (x[6]-0.5)** 2  +(x[7] -0.5)** 2  +(x[8] -0.5)** 2  +(x[9]-0.5)** 2
    return b

def y1_imops(x,k,a1):
    res = (1/5 * (x[0] + x[1] +  x[2]  +  x[3] + x[4] ) ) ** 0.05
    return res

def y2_imops(x,k,a2):
    a = (3 * ( x[0]+x[1]+x[2]))  ** 0.05
    return a

def y3_imops(x,k,a3):
    a = ((0.5)* (x[3]+x[4])) ** 10
    return a
'''

def IMOP1(x,k,a1,a2,a3,n_vars):
    y1 = y1_imops(x,k,a1)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    f1 = g + np.cos(np.pi*0.5*y1)**8
    f2 = g + np.sin(np.pi*0.5*y1)**8
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    return evaluation

def IMOP2(x,k,a1,a2,a3,n_vars):
    y1 = y1_imops(x,k,a1)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    f1 = g + np.cos(np.pi*0.5*y1)**0.5
    f2 = g + np.sin(np.pi*0.5*y1)**0.5
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    return evaluation

def IMOP3(x,k,a1,a2,a3,n_vars):
    y1 = y1_imops(x,k,a1)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    f1 = g + 1 + 0.2*np.cos(10*np.pi*y1) - y1
    f2 = g + y1
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    return evaluation
    
def IMOP4(x,k,a1,a2,a3,n_vars):
    y1 = y1_imops(x,k,a1)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    f1 = (1+g)*y1
    f2 = (1+g)*(y1+(0.1*np.sin(10*np.pi*y1)))
    f3 = (1+g)*(1-y1)
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def IMOP5(x,k,a1,a2,a3,n_vars):
    y2 = y2_imops(x,k,a2)
    y3 = y3_imops(x,k,a3)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    h1 = 0.4*np.cos((np.pi/4)*(math.ceil(8*y2))) + 0.1*y3*np.cos(16*np.pi*y2)
    h2 = 0.4*np.sin((np.pi/4)*(math.ceil(8*y2))) + 0.1*y3*np.sin(16*np.pi*y2)
    f1 = g+h1
    f2 = g+h2
    f3 = g+0.5-h1-h2
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def IMOP6(x,k,a1,a2,a3,n_vars):
    y2 = y2_imops(x,k,a2)
    y3 = y3_imops(x,k,a3)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    r = max(0,min((np.sin(3*np.pi*y2)**2),(np.sin(3*np.pi*y3)**2))-0.5)
    f1 = (1+g)*y2 + math.ceil(r)
    f2 = (1+g)*y3 + math.ceil(r)
    f3 = (0.5+g)*(2-y2-y3) + math.ceil(r)
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def IMOP7(x,k,a1,a2,a3,n_vars):
    y2 = y2_imops(x,k,a2)
    y3 = y3_imops(x,k,a3)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    h1 = (1+g)*np.cos(0.5*np.pi*y2)*np.cos(0.5*np.pi*y3)
    h2 = (1+g)*np.cos(0.5*np.pi*y2)*np.sin(0.5*np.pi*y3)
    h3 = (1+g)*np.sin(0.5*np.pi*y2)
    r = min(min(np.absolute(h1-h2),np.absolute(h2-h3)),np.absolute(h3-h1))
    f1 = h1 + 10*max(0,r-0.1)
    f2 = h2 + 10*max(0,r-0.1)
    f3 = h3 + 10*max(0,r-0.1)
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def sumatoryIMOP8(yi,g):
    a = yi*(1+np.sin(19*np.pi*yi))
    b = 1+g
    return a/b

def IMOP8(x,k,a1,a2,a3,n_vars):
    y2 = y2_imops(x,k,a2)
    y3 = y3_imops(x,k,a3)
    evaluation = np.array([])
    g = g_imops(x,k,n_vars)
    yi2 = sumatoryIMOP8(y2,g)
    yi3 = sumatoryIMOP8(y3,g)
    f1 = y2
    f2 = y3
    f3 = (1+g)*(3-yi2-yi3)
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation


# VIENNET Test Functions. 
def VIE1_data(n_vars):
    return same_boundaries(n_vars,-2,2)

def VIE1(sol,n_vars):
    x = sol[0]
    y = sol[1]
    evaluation = np.array([])
    f1 = x**2 + (y-1)**2
    f2 = x**2 + (y+1)**2 + 1
    f3 = (x-1)**2 + y**2 + 2
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def VIE2_data(n_vars):
    return same_boundaries(n_vars,-4,4)

def VIE2(sol,n_vars):
    x = sol[0]
    y = sol[1]
    evaluation = np.array([])
    f1 = (1/2)*((x-2)**2) + (1/13)*((y+1)**2) + 3
    f2 = (1/36)*((x+y-3)**2) + (1/8)*((-x+y+2)**2) - 17
    f3 = (1/175)*((x+2*y-1)**2) + (1/17)*((2*y-x)**2) - 13
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation

def VIE3_data(n_vars):
    return same_boundaries(n_vars,-3,3)

def VIE3(sol,n_vars):
    x = sol[0]
    y = sol[1]
    evaluation = np.array([])
    f1 = 0.5*(x**2+y**2) + np.sin(x**2+y**2)
    f2 = (1/8)*((3*x-2*y+4)**2) + (1/27)*((x-y+1)**2) + 15
    f3 = (1/(x**2+y**2+1)) - 1.1*(np.exp(-1*(x**2+y**2)))
    evaluation = np.append(evaluation,f1) 
    evaluation = np.append(evaluation,f2) 
    evaluation = np.append(evaluation,f3)
    return evaluation


# WFG Test Problems thy are implemented with the pymoo library.

# WFG
def WFG_data(n_vars):
    data = WFG_data_boundaries(n_vars,0,2)
    return data

def WFG_data_boundaries(n_vars,a,b):
    data = np.array([])
    for i in range(n_vars):
        data = np.append(data,a)
        data = np.append(data,(i+1)*b)
    return data

# WFG
def ZCAT_data(n_vars):
    data = ZCAT_data_boundaries(n_vars,-0.5,0.5)
    return data

def ZCAT_data_boundaries(n_vars,a,b):
    data = np.array([])
    for i in range(n_vars):
        data = np.append(data,(i+1)*a)
        data = np.append(data,(i+1)*b)
    return data



