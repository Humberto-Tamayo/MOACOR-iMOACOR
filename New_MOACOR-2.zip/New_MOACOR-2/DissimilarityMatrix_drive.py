"""
Dissimilarity matrix.
"""

import numpy as np
from scipy.spatial import distance

def dissimilarityMatrix(A, ppf):  
    """Calculates dissimilarity matrix using a given pair-potential kernel"""
    if ppf == 'RSE':
        m = np.shape(A)[1]
        Diss = dissimilarityMatrixRSE(A, m-1)
    elif ppf == 'GAE':
        Diss = dissimilarityMatrixGAE(A, 512)
    elif ppf == 'COU':
        Diss = dissimilarityMatrixCOU(A)
    elif ppf == 'PTP':
        Diss = dissimilarityMatrixPTP(A, 5, 3, 0.02)
    elif ppf == 'MPT':
        Diss = dissimilarityMatrixMPT(A, 1, 25)
    elif ppf == 'KRA':
        Diss = dissimilarityMatrixKRA(A, 5, 3, 0.02)
    return Diss

def dissimilarityMatrixRSE(A, s):
    """Returns dissimilarity matrix using Riesz s-energy"""
    d = distance.pdist(A, 'euclidean')
    denom = d**s
    denom[denom == 0] = 1e-12
    d = 1/denom
    return distance.squareform(d)

def dissimilarityMatrixGAE(A, alpha):
    """Returns dissimilarity matrix using Gaussian alpha-energy"""
    d = distance.pdist(A, 'euclidean')
    d = np.e**(-alpha*(d**2))
    return distance.squareform(d)

def dissimilarityMatrixCOU(A):
    """Returns dissimilarity matrix using Coulomb's law"""
    k = 1/(4*np.pi*8.854e-12)
    norm = np.linalg.norm(A, axis=1)
    V = np.outer(norm, norm)
    np.fill_diagonal(V, 0)
    v = distance.squareform(V)
    d = distance.pdist(A, 'euclidean')
    denom = d**2
    denom[denom == 0] = 1e-12
    d = k*v/denom
    return distance.squareform(d)

def dissimilarityMatrixPTP(A, V1, V2, alpha):
    """Returns dissimilarity matrix using Pösch-Teller Potential"""
    d = distance.pdist(A, 'euclidean')
    denom1 = np.sin(alpha*d)**2
    denom1[denom1 == 0] = 1e-12
    denom2 = np.cos(alpha*d)**2
    denom2[denom2 == 0] = 1e-12
    d = V1/denom1+V2/denom2
    return distance.squareform(d)

def dissimilarityMatrixMPT(A, D, alpha):
    """Returns dissimilarity matrix using Modified Pösch-Teller Potential"""
    d = distance.pdist(A, 'euclidean')
    d = D/(np.cosh(alpha*d)**2)
    return distance.squareform(d)

def dissimilarityMatrixKRA(A, V1, V2, alpha):
    """Returns dissimilarity matrix using Kratzer Potential"""
    d = distance.pdist(A, 'euclidean')
    denom = np.copy(d)
    denom[denom == 0] = 1e-12
    d = V1*(((d-(1/alpha))/denom)**2)+V2
    return distance.squareform(d)
