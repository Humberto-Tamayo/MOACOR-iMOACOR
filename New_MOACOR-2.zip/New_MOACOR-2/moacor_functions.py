#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 00:01:11 2023

@author: macbook
"""

from zcat_benckmark import *


import MOP_test_problems as MOP_tp

import matplotlib.pyplot as plt
import numpy as np

import plotly.graph_objects as go



def crowding_distance_Func(point, points):
    # Find the nearest neighbors of the point
    distances = np.sum((points - point)**2, axis=1)
    nearest = np.argpartition(distances, 2)[:2]
    nearest_points = points[nearest]
    
    # Calculate the crowding distance as the sum of the distances to the nearest neighbors
    crowding_distance = np.sum(np.sqrt(np.sum((nearest_points - point)**2, axis=1)))
    
    return crowding_distance


def dominates(point, points):
    #print(point)
    #print(points)
    index = np.where(np.all(point == points,axis=1))[0]
    #points = np.delete(points,index[0],0) I have modified this line later
    points = np.delete(points,index,0)
    #print(points)
    # Check if there are any points in the set that are non-dominated by the input point
    non_dominated = np.any(np.all(points <= point, axis=1))
    # Return True if the input point dominates all points in the set, and False otherwise
    return not non_dominated


def random_solution(mop_ranges):
    a = int(len(mop_ranges)/2)
    rand_sol = np.array([])
    for i in range(a):
        rand_sol = np.append(rand_sol,np.random.uniform(mop_ranges[i*2], mop_ranges[i*2+1]))
    return rand_sol

def initial_random_solutions(mop_ranges,n_sols):
    a = int(len(mop_ranges)/2)
    init_sols = np.empty([a])
    for _ in range(n_sols):
        rand_sol = random_solution(mop_ranges)
        init_sols = np.vstack((init_sols, rand_sol))
    init_sols = np.delete(init_sols,0,0)
    return init_sols

def mop_data_func(n_vars,problem):
    if problem == "BETO1":
        return MOP_tp.mop_beto1_data(n_vars)
    elif problem == "SCH1":
        return MOP_tp.SCH1_data(n_vars)
    elif problem == "SCH2":
        return MOP_tp.SCH2_data(n_vars)
    elif problem == "DEB1":
        return MOP_tp.DEB1_data(n_vars)
    elif "DTLZ1"  in problem:
        return MOP_tp.DTLZ1_data(n_vars)
    elif "DTLZ2"  in problem:
        return MOP_tp.DTLZ2_data(n_vars)
    elif "DTLZ3"  in problem:
        return MOP_tp.DTLZ3_data(n_vars)
    elif "DTLZ4"  in problem:
        return MOP_tp.DTLZ4_data(n_vars)
    elif "DTLZ5"  in problem:
        return MOP_tp.DTLZ5_data(n_vars)
    elif "DTLZ6"  in problem:
        return MOP_tp.DTLZ6_data(n_vars)
    elif "DTLZ7"  in problem:
        return MOP_tp.DTLZ7_data(n_vars)
    elif "WFG" in problem: 
        return MOP_tp.WFG_data(n_vars)
    elif "IMOP" in problem:
        return MOP_tp.IMOPS_data(n_vars)
    elif "VIE1" in problem:
        return MOP_tp.VIE1_data(n_vars)
    elif "VIE2" in problem:
        return MOP_tp.VIE2_data(n_vars)
    elif "VIE3" in problem:
        return MOP_tp.VIE3_data(n_vars)
    elif "ZCAT" in problem: 
        return MOP_tp.ZCAT_data(n_vars)
    print("Error")
    return "not a problem"

def evaluate_solutions(sols,n_funcs,problem,n_vars):

    Level = 1  # Level of the problem {1,..,6}
    Bias_flag = 0  # Bias flag {0,1}  (True: 1, False: 0)
    Complicated_PS_flag = 0  # Complicated PS flag {0,1} (True: 1, False: 0)
    Imbalance_flag = 0  # Imbalance flag {0,1}  (True: 1, False: 0)

    # Configuring ZCAT benchmark. LB and UB are pointers to the bounds in the ZCAT structures
    LB, UB, zcat_config = zcat_set(n_vars, n_funcs, Level, Bias_flag, Complicated_PS_flag, Imbalance_flag)
    
    evaluated_sols = np.empty([n_funcs])
    for sol in sols:
        if problem == "SCH1":
            evaluation = MOP_tp.SCH1(sol)
        elif problem == "SCH2":
            evaluation = MOP_tp.SCH2(sol)
        elif problem == "DEB1":
            evaluation = MOP_tp.DEB1(sol)
        elif "DTLZ1"  in problem:
            evaluation = MOP_tp.DTLZ1(sol,n_funcs,n_vars)
        elif "DTLZ2"  in problem:
            evaluation = MOP_tp.DTLZ2(sol,n_funcs,n_vars)
        elif "DTLZ3"  in problem:
            evaluation = MOP_tp.DTLZ3(sol,n_funcs,n_vars)
        elif "DTLZ4"  in problem:
            evaluation = MOP_tp.DTLZ4(sol,n_funcs,n_vars)
        elif "DTLZ5"  in problem:
            evaluation = MOP_tp.DTLZ5(sol,n_funcs,n_vars)
        elif "DTLZ6"  in problem:
            evaluation = MOP_tp.DTLZ6(sol,n_funcs,n_vars)
        elif "DTLZ7"  in problem:
            evaluation = MOP_tp.DTLZ7(sol,n_funcs,n_vars)
        elif "IMOP1" in problem:
            evaluation = MOP_tp.IMOP1(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP2" in problem:
            evaluation = MOP_tp.IMOP2(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP3" in problem:
            evaluation = MOP_tp.IMOP3(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP4" in problem:
            evaluation = MOP_tp.IMOP4(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP5" in problem:
            evaluation = MOP_tp.IMOP5(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP6" in problem:
            evaluation = MOP_tp.IMOP6(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP7" in problem:
            evaluation = MOP_tp.IMOP7(sol,5,0.05,0.05,10,n_vars)
        elif "IMOP8" in problem:
            evaluation = MOP_tp.IMOP8(sol,5,0.05,0.05,10,n_vars)
        elif "VIE1" in problem:
            evaluation = MOP_tp.VIE1(sol,n_vars)
        elif "VIE2" in problem:
            evaluation = MOP_tp.VIE2(sol,n_vars)
        elif "VIE3" in problem:
            evaluation = MOP_tp.VIE3(sol,n_vars)
            
            
        elif "ZCAT1" == problem:
            evaluation = ZCAT1(sol,zcat_config)
        elif "ZCAT2" == problem:
            evaluation = ZCAT2(sol,zcat_config)
        elif "ZCAT3" == problem:
            evaluation = ZCAT3(sol,zcat_config)
        elif "ZCAT4" == problem:
            evaluation = ZCAT4(sol,zcat_config)
        elif "ZCAT5" == problem:
            evaluation = ZCAT5(sol,zcat_config)
        elif "ZCAT6" == problem:
            evaluation = ZCAT6(sol,zcat_config)
        elif "ZCAT7" == problem:
            evaluation = ZCAT7(sol,zcat_config)
        elif "ZCAT8" == problem:
            evaluation = ZCAT8(sol,zcat_config)
        elif "ZCAT9" == problem:
            evaluation = ZCAT9(sol,zcat_config)
        elif "ZCAT10" == problem:
            evaluation = ZCAT10(sol,zcat_config)
        elif "ZCAT11" == problem:
            evaluation = ZCAT11(sol,zcat_config)
        elif "ZCAT12" == problem:
            evaluation = ZCAT12(sol,zcat_config)
        elif "ZCAT13" == problem:
            evaluation = ZCAT13(sol,zcat_config)
        elif "ZCAT14" == problem:
            evaluation = ZCAT14(sol,zcat_config)
        elif "ZCAT15" == problem:
            evaluation = ZCAT15(sol,zcat_config)
        elif "ZCAT16" == problem:
            evaluation = ZCAT16(sol,zcat_config)
        elif "ZCAT17" == problem:
            evaluation = ZCAT17(sol,zcat_config)
        elif "ZCAT18" == problem:
            evaluation = ZCAT18(sol,zcat_config)
        elif "ZCAT19" == problem:
            evaluation = ZCAT19(sol,zcat_config)
        elif "ZCAT20" == problem:
            evaluation = ZCAT20(sol,zcat_config)
            
        else:
            print("Not a valid problem")   
        evaluated_sols = np.vstack((evaluated_sols,evaluation))
    evaluated_sols = np.delete(evaluated_sols,0,0)
    if "IDTLZ" in problem:
        evaluated_sols = -1*evaluated_sols
    return evaluated_sols

def keep_solutions(sols,eval_sols,n_fronts,k):
    b = eval_sols.shape[1]
    best_sols_eval = np.empty([b])
    a = sols.shape[1]
    best_sols = np.empty([a])
    frontier = np.empty([1])
    counter = 1
    for i in range(n_fronts):
        if ((i > 0) and (counter > k)):
            break
        indexes = []
        for eval_sol in eval_sols:
            if (dominates(eval_sol,eval_sols)):
                result = np.where(np.all(eval_sols == eval_sol,axis=1))
                indexes.append(result[0][0])
                counter = counter + 1
        indexes = np.flip(indexes)
        for index in indexes:
            best_sols_eval = np.vstack((best_sols_eval,eval_sols[index]))
            best_sols = np.vstack((best_sols,sols[index]))
            eval_sols = np.delete(eval_sols,index,0)
            sols = np.delete(sols,index,0)
            frontier = np.vstack((frontier,i+1))
    best_sols_eval = np.delete(best_sols_eval,0,0)
    best_sols = np.delete(best_sols,0,0)
    frontier = np.delete(frontier,0,0)
    return best_sols_eval,best_sols,frontier

#Function to generate a new solution depending on the previous chosen solution
def newSolution(archive,chosenSolution,epsilon,mop_data,n_var):
    miu = []
    sigma = []
    newSolution = []
    a = archive.shape[0]
    for i in range(n_var):
        miu.append(chosenSolution[i])   
    for x in range(n_var):
        sigmaInstance = 0
        for y in range(a):
            sigmaInstance = sigmaInstance + abs(miu[x] - archive[y][x])
        sigmaInstance = epsilon * sigmaInstance / (a-1)
        sigma.append(sigmaInstance)
    for i in range(n_var):
        temp = np.random.normal(miu[i], sigma[i])
        if temp < mop_data[2*i]:
            temp = mop_data[2*i]
        if temp > mop_data[2*i+1]:
            temp = mop_data[2*i+1]
        newSolution.append(temp)    
    return newSolution

#Orders the first generated solutions and stores it in the archive.
def ranking(q,k,archive):
    a = archive.shape[1]
    rank = []
    part1 = 1 / ( q * k * ( 2 * np.pi) ** 0.5)
    for i in range(k):
        part2 = np.exp( - ( ((i)**2) / (2 * q**2 * k**2) ) )
        weight = part1*part2
        archive[i][a-1] = weight
    return archive

def all_crowding_distances(archive,n_vars,n_funcs):
    crowding = np.empty([1])
    temp_archive = archive[:,n_vars:(n_funcs+n_vars)]
    for evaluation in temp_archive:
        crowding = np.vstack((crowding,crowding_distance_Func(evaluation,temp_archive)))
    crowding = np.delete(crowding,0,0)
    return crowding




def delete_sols(archive,k):
    a = archive.shape[0]-1
    while (a>k-1):
        archive = np.delete(archive,a,0)
        a = archive.shape[0]-1
    return archive

def concatenate_archive(best_sols,best_sols_eval,frontier,n_vars,n_funcs):
    archive = np.concatenate((best_sols,best_sols_eval), axis=1)
    archive = np.concatenate((archive,frontier),axis=1)
    crowding_distances = all_crowding_distances(archive,n_vars,n_funcs)
    archive = np.concatenate((archive,crowding_distances),axis=1)
    archive = archive[archive[:,n_funcs+n_vars+1].argsort()][::-1]
    archive = archive[archive[:,n_funcs+n_vars].argsort()]
    return archive



def nadir_vector(matrix):
    num_cols = len(matrix[0])
    max_vals = [-float('inf')] * num_cols
    for col_idx in range(num_cols):
        for row_idx in range(len(matrix)):
            if matrix[row_idx][col_idx] > max_vals[col_idx]:
                max_vals[col_idx] = matrix[row_idx][col_idx]
    return max_vals

def ideal_vector(matrix):
    num_cols = len(matrix[0])
    min_vals = [float('inf')] * num_cols
    for col_idx in range(num_cols):
        for row_idx in range(len(matrix)):
            if matrix[row_idx][col_idx] < min_vals[col_idx]:
                min_vals[col_idx] = matrix[row_idx][col_idx]
    return min_vals

def normalize(archive):
    ideal = ideal_vector(archive)
    nadir = nadir_vector(archive)
    normalized_archive = archive.copy()
    n_funcs = archive.shape[1]
    count = 0
    for p in archive:
        for i in range(n_funcs):
            a = (p[i]-ideal[i])/(nadir[i]-ideal[i])
            normalized_archive[count,i] = a
        count = count + 1
    return normalized_archive

def crowding_distance_as_NSGA_II(aproximation):
    l = aproximation.shape[0]
    order = np.arange(l).reshape(-1,1)
    normalized_aproximation = normalize(aproximation)
    crowding_distances = np.zeros((l,1))
    crowding_distances = np.concatenate((crowding_distances, order), axis=1)
    normalized_aproximation = np.concatenate((normalized_aproximation, crowding_distances), axis=1)
    m = aproximation.shape[1] - 1
    for obj in range(m):
        normalized_aproximation = normalized_aproximation[normalized_aproximation[:,obj].argsort()]
        normalized_aproximation[0,m] = np.inf
        normalized_aproximation[l-1,m] = np.inf
        for i in range(l-2):
            normalized_aproximation[i+1,m] = normalized_aproximation[i+1,m] + normalized_aproximation[i,obj] - normalized_aproximation[i+2,obj]
    normalized_aproximation = normalized_aproximation[normalized_aproximation[:,m+1].argsort()]
    crowding_distances = normalized_aproximation[:,m].reshape((-1,1))
    return crowding_distances


def concatenate_archive_with_crowding_as_NSGA_II(best_sols,best_sols_eval,frontier,n_vars,n_funcs):
    archive = np.concatenate((best_sols,best_sols_eval), axis=1)
    archive = np.concatenate((archive,frontier),axis=1)
    crowding_distances = crowding_distance_as_NSGA_II(archive[:,n_vars:n_vars+n_funcs])
    archive = np.concatenate((archive,crowding_distances),axis=1)
    archive = archive[archive[:,n_funcs+n_vars+1].argsort()][::-1]
    archive = archive[archive[:,n_funcs+n_vars].argsort()]
    return archive


def normalize_array_from1_to50(arr):
    min_val = min(arr)
    max_val = max(arr)
    normalized_array = [1 + ((x - min_val) / (max_val - min_val)) * 49 for x in arr]
    return normalized_array

def selection_weights(q,k):
    ranking_array = np.empty([1])
    array_to_normalize = list(range(1, k+1))
    normalized_array = normalize_array_from1_to50(array_to_normalize)
    part1 = 1 / ( q * 50 * ( 2 * np.pi) ** 0.5)
    for i in normalized_array:
        part2 = np.exp( - ( ((i)**2) / (2 * q**2 * k**2) ) )
        weight = part1*part2
        ranking_array = np.vstack((ranking_array,weight))
    ranking_array = np.delete(ranking_array,0,0)
    return ranking_array

def chooseSolution(archive):
    k = archive.shape[0]
    sumatory = 0
    for x in range(k):
        sumatory = archive[x][-1] + sumatory
    rand = np.random.uniform() * sumatory
    sumatory = 0
    for y in range(k):
        sumatory = archive[y][-1] + sumatory
        if (sumatory > rand):
            chosen_sol = archive[y]
            break
    return chosen_sol



































